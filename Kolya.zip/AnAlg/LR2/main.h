#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "matrio.h"
#include "memory.h"
#include "matrproc.h"
#include "errors.h"


int multiple_plus(int argc, char * argv[]);
int determinant(int argc, char * argv[]);
void view_spr();

