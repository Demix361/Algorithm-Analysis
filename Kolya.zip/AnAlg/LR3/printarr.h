#ifndef printarr_h
#define printarr_h

#include <stdio.h>
#include <stdlib.h>

void printarr(int * pst, int * plast);

#endif
