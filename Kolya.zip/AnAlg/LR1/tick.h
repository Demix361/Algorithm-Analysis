unsigned long long tick(void);
