struct Vinograd_data
{
    Matrix matr1;
    Matrix matr2;
    double *mulh;
    double *mulv;
    Matrix res;
};
