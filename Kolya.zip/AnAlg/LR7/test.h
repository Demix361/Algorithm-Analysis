#ifndef TEST_H
#define TEST_H

#include <string>
#include <vector>
#include <fstream>
#include <iostream>
#include "search_string.h"

int test(std::string filename);

#endif // TEST_H
