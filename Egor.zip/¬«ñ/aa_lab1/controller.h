#pragma once

#include <iostream>
#include <string>
#include <memory>

void enter_word(std::string&, std::string);
void controller();
