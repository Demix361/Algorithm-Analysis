#include "controller.h"
#include "levenshtein.h"
#include "tests.h"
#include "metering.h"


int main(int argc, char *argv[])
{
    //metering();
    controller();


//    app.exe : 
//    g++ -std=c++17 -Wall -Werror -pedantic -D RELEASE main.cpp controller.cpp levenshtein.cpp -o app.exe

//    test.exe :
//    g++ -std=c++17 -Wall -Werror -pedantic test.cpp levenshtein.cpp -o test.exe
    return 0;
}
