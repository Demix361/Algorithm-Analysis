#pragma once

void tests();
