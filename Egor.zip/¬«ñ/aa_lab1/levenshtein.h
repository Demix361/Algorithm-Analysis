#pragma once

#include <iostream>
#include <vector>
#include <string>
#include <memory>
#include <limits>


int lev_matr_dist(std::string, std::string);
int dam_lev_matr_dist(std::string, std::string);
int dam_lev_rec_dist(std::string, std::string);
