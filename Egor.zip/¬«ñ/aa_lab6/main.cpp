#include <iostream>
#include <string>
#include <vector>
#include <cassert>
#include "total_search.h"
#include "aco.h"
#include "matrix.h"
#include "print.h"
#include "res.h"
#include "controller.h"
#include "test_.h"

int main() {
    //research_();
    //controller();
    test();

    return 0;
}
