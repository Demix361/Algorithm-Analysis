#ifndef RES_H
#define RES_H

int research_();

#endif // RES_H
