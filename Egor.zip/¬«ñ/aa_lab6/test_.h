#ifndef TEST__H
#define TEST__H

void test();

#endif // TEST__H
