#pragma once

#include<vector>

#define N_MIN	3			// минимальное количество вершин
#define N_MAX	30			// максимальное количество вершин

using Matrix = std::vector<std::vector<double>>;
