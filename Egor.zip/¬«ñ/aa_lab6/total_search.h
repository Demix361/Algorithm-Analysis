#pragma once

#include <vector>
#include "matrix.h"

double total_search(Matrix matrix, std::vector<int> &way);
