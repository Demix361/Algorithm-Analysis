#pragma once

#include <iostream>
#include <vector>

#define BOARD_LENGTH 79

void board();
void print_way(std::vector<int> way);
