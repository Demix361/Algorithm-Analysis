#include <iostream>
#include "conveyor.h"

using namespace std;

int main()
{
    conveyor();
    return 0;
}
