#pragma once

int meter();
