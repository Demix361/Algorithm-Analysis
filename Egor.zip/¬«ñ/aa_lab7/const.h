#pragma once

#define WRONG_LEN -1
#define NOT_FOUND -2
