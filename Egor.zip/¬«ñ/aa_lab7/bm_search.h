#pragma once

#include <string>
#include <vector>
#include <algorithm>
#include "const.h"
#include "shift.h"

int bm_search(const std::string &text, const std::string &pattern);
