#include "controller.h"
#include "test.h"

int main() {
   controller();
   //tests();
    
    return 0;
}
