#pragma once

#include <iostream>
#include <vector>

#define BOARD_LENGTH 79

void board();
void print(const std::vector<int> &v);
