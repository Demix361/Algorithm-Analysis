#pragma once

#include <string>
#include <vector>

std::vector<int> get_shift(const std::string &str);
