#pragma once

#include <iostream>
#include <string>
#include <memory>
#include <vector>

void enter_word(std::string&, std::string);
void controller();