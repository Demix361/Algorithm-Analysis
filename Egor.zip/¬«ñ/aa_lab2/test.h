#pragma once

void test();
